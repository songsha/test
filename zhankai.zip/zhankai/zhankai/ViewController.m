//
//  ViewController.m
//  zhankai
//
//  Created by apple on 16/8/30.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "ViewController.h"
#define SCREENW [UIScreen mainScreen].bounds.size.width
#define SCREENH [UIScreen mainScreen].bounds.size.height
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView * tableview;
@property (nonatomic,strong)NSMutableArray * selectArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    _selectArray=[[NSMutableArray alloc]init];
    
    
    _tableview=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREENW, SCREENH) style:UITableViewStyleGrouped];
    _tableview.delegate=self;
    _tableview.dataSource=self;
//    _tableview.separatorColor=[UIColor clearColor];
    _tableview.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableview];
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    if (_selectArray.count>0) {
        for (int i=0; i<_selectArray.count; i++) {
            if (section==[_selectArray[i]integerValue]) {
                return 2;
            }
        }
    }
    
    return 1;
    
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 22;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 50;


}
// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (indexPath.row==0) {
        UITableViewCell * cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
        }
        cell.imageView.image=[UIImage imageNamed:@"53"];
        //    cell.selected=1;
        //    if (_selectArray.count>0) {
        //        for (int i=0; i<_selectArray.count; i++) {
        //            if (indexPath.section==[_selectArray[i]integerValue]) {
        //                cell.selected=0;
        //            }
        //        }
        //    }
        
        // NSLog(@"%d", cell.selected);
        
        
        return cell;

    }
    
    
        UITableViewCell * cell=[tableView dequeueReusableCellWithIdentifier:@"ID2"];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID2"];
        }
        cell.textLabel.text=@"22222";
        //    cell.selected=1;
        //    if (_selectArray.count>0) {
        //        for (int i=0; i<_selectArray.count; i++) {
        //            if (indexPath.section==[_selectArray[i]integerValue]) {
        //                cell.selected=0;
        //            }
        //        }
        //    }
        
        // NSLog(@"%d", cell.selected);
        
        
        return cell;
        
   
    

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell * cell=[tableView cellForRowAtIndexPath:indexPath];
     NSLog(@"%d", cell.selected);
    

    if (_selectArray.count>0) {
        int i;
        int count=(int)_selectArray.count;
        for ( i=0; i<_selectArray.count; i++) {
            
            NSLog(@"%@ %@",[NSString stringWithFormat:@"%d",(int)indexPath.section],_selectArray[i])  ;
            
            if ([[NSString stringWithFormat:@"%d",(int)indexPath.section]isEqualToString:_selectArray[i]]) {
               [_selectArray removeObject:[NSString stringWithFormat:@"%d",(int)indexPath.section]];
                break;
            }
        }
        if (i>=_selectArray.count&&_selectArray.count==count) {
            [_selectArray addObject:[NSString stringWithFormat:@"%d",(int)indexPath.section]];

        }
    }
    else
        [_selectArray addObject:[NSString stringWithFormat:@"%d",(int)indexPath.section]];
   
    
    
//    if (cell.selected) {
//        [_selectArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
//    }
//    else{
//        [_selectArray removeObject:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
//    
//    }
    if (cell.selected==0) {
        cell.selected=1;
    }
    else
        cell.selected=0;
   // NSLog(@"%d",cell.selected);
    [_tableview reloadData];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
